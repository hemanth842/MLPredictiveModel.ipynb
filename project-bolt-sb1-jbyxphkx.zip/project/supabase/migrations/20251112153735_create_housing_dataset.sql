/*
  # Housing Dataset Schema

  1. New Tables
    - `housing_data`
      - `id` (uuid, primary key)
      - `square_feet` (numeric) - Property square footage
      - `bedrooms` (integer) - Number of bedrooms
      - `bathrooms` (numeric) - Number of bathrooms
      - `age_years` (integer) - Age of house in years
      - `price` (numeric) - Sale price in USD
      - `created_at` (timestamptz)

    - `housing_predictions`
      - `id` (uuid, primary key)
      - `model_type` (text) - Model used for prediction
      - `square_feet` (numeric)
      - `bedrooms` (integer)
      - `bathrooms` (numeric)
      - `age_years` (integer)
      - `predicted_price` (numeric)
      - `actual_price` (numeric, nullable)
      - `error_percentage` (numeric, nullable)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Public read/write access for demo purposes

  3. Notes
    - Housing dataset with realistic property values
    - Predictions tracked for model evaluation
*/

CREATE TABLE IF NOT EXISTS housing_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  square_feet numeric NOT NULL,
  bedrooms integer NOT NULL,
  bathrooms numeric NOT NULL,
  age_years integer NOT NULL,
  price numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS housing_predictions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  model_type text NOT NULL,
  square_feet numeric NOT NULL,
  bedrooms integer NOT NULL,
  bathrooms numeric NOT NULL,
  age_years integer NOT NULL,
  predicted_price numeric NOT NULL,
  actual_price numeric,
  error_percentage numeric,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE housing_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE housing_predictions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view housing data"
  ON housing_data FOR SELECT
  USING (true);

CREATE POLICY "Anyone can view predictions"
  ON housing_predictions FOR SELECT
  USING (true);

CREATE POLICY "Anyone can create predictions"
  ON housing_predictions FOR INSERT
  WITH CHECK (true);

INSERT INTO housing_data (square_feet, bedrooms, bathrooms, age_years, price) VALUES
(1500, 3, 2, 10, 350000),
(2000, 4, 2.5, 5, 485000),
(1200, 2, 1, 25, 275000),
(2500, 4, 3, 2, 620000),
(1800, 3, 2, 15, 395000),
(2200, 4, 2.5, 8, 520000),
(1400, 2, 2, 30, 290000),
(2800, 5, 3, 1, 750000),
(1600, 3, 2, 20, 340000),
(2100, 4, 2.5, 7, 510000),
(1300, 2, 1.5, 35, 260000),
(2400, 4, 3, 3, 600000),
(1700, 3, 2, 12, 375000),
(2300, 4, 2.5, 9, 535000),
(1450, 3, 2, 18, 330000),
(1900, 3, 2.5, 11, 420000),
(2600, 5, 3, 4, 680000),
(1350, 2, 1, 40, 245000),
(2050, 4, 2.5, 6, 485000),
(1550, 3, 2, 22, 345000);