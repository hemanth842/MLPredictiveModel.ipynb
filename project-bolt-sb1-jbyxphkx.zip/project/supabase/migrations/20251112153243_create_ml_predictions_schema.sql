/*
  # ML Predictive Model Database Schema

  1. New Tables
    - `predictions`
      - `id` (uuid, primary key) - Unique identifier for each prediction
      - `model_type` (text) - Type of model used (linear_regression, decision_tree, neural_network)
      - `input_data` (jsonb) - Input features used for prediction
      - `prediction_result` (jsonb) - Model output and confidence scores
      - `accuracy` (numeric) - Model accuracy percentage
      - `created_at` (timestamptz) - Timestamp of prediction
    
    - `training_data`
      - `id` (uuid, primary key) - Unique identifier
      - `model_type` (text) - Associated model type
      - `features` (jsonb) - Training features
      - `target` (numeric) - Target variable
      - `created_at` (timestamptz) - Timestamp

  2. Security
    - Enable RLS on all tables
    - Public read access for demo purposes
    - Authenticated users can create predictions

  3. Notes
    - Using JSONB for flexible feature storage
    - Supports multiple model types
    - Tracks prediction history and accuracy
*/

CREATE TABLE IF NOT EXISTS predictions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  model_type text NOT NULL,
  input_data jsonb NOT NULL,
  prediction_result jsonb NOT NULL,
  accuracy numeric DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS training_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  model_type text NOT NULL,
  features jsonb NOT NULL,
  target numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_data ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view predictions"
  ON predictions FOR SELECT
  USING (true);

CREATE POLICY "Anyone can create predictions"
  ON predictions FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can view training data"
  ON training_data FOR SELECT
  USING (true);

CREATE POLICY "Anyone can add training data"
  ON training_data FOR INSERT
  WITH CHECK (true);