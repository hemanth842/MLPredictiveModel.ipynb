import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Prediction {
  id: string;
  model_type: string;
  input_data: {
    squareFeet: number;
    bedrooms: number;
    bathrooms: number;
    ageYears: number;
  };
  prediction_result: {
    predictedPrice: number;
    confidence: number;
    estimatedError?: number;
  };
  accuracy: number;
  created_at: string;
}

export interface TrainingData {
  id: string;
  model_type: string;
  features: Record<string, number>;
  target: number;
  created_at: string;
}
