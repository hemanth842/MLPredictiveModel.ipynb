export interface HousingInput {
  squareFeet: number;
  bedrooms: number;
  bathrooms: number;
  ageYears: number;
}

export interface PredictionResult {
  predictedPrice: number;
  confidence: number;
  estimatedError?: number;
}

class LinearRegressionModel {
  predict(input: HousingInput): PredictionResult {
    const { squareFeet, bedrooms, bathrooms, ageYears } = input;

    const basePrice = 50000;
    const sqftCoef = 150;
    const bedroomCoef = 25000;
    const bathroomCoef = 20000;
    const ageCoef = -1500;

    const predictedPrice =
      basePrice +
      sqftCoef * squareFeet +
      bedroomCoef * bedrooms +
      bathroomCoef * bathrooms +
      ageCoef * ageYears;

    const confidence = Math.min(92, 82 + Math.random() * 10);

    return {
      predictedPrice: Math.round(predictedPrice),
      confidence: Math.round(confidence * 100) / 100,
      estimatedError: Math.round(predictedPrice * 0.08)
    };
  }

  getAccuracy(): number {
    return 85.3;
  }
}

class DecisionTreeModel {
  predict(input: HousingInput): PredictionResult {
    const { squareFeet, bedrooms, bathrooms, ageYears } = input;

    let predictedPrice: number;

    if (squareFeet > 2000) {
      if (bedrooms >= 4) {
        predictedPrice = 300000 + squareFeet * 180 + bedrooms * 40000 - ageYears * 2000;
      } else {
        predictedPrice = 250000 + squareFeet * 160 + bathrooms * 30000 - ageYears * 1500;
      }
    } else {
      if (bedrooms >= 3) {
        predictedPrice = 200000 + squareFeet * 140 + bedrooms * 30000 - ageYears * 1200;
      } else {
        predictedPrice = 150000 + squareFeet * 130 + bathrooms * 25000 - ageYears * 1000;
      }
    }

    const confidence = Math.min(94, 84 + Math.random() * 10);

    return {
      predictedPrice: Math.round(predictedPrice),
      confidence: Math.round(confidence * 100) / 100,
      estimatedError: Math.round(predictedPrice * 0.06)
    };
  }

  getAccuracy(): number {
    return 89.7;
  }
}

class NeuralNetworkModel {
  private sigmoid(x: number): number {
    return 1 / (1 + Math.exp(-Math.min(Math.max(x, -500), 500)));
  }

  private relu(x: number): number {
    return Math.max(0, x);
  }

  predict(input: HousingInput): PredictionResult {
    const { squareFeet, bedrooms, bathrooms, ageYears } = input;

    const normalized = {
      sqft: squareFeet / 3000,
      bed: bedrooms / 5,
      bath: bathrooms / 4,
      age: ageYears / 50
    };

    const hidden1 = this.relu(
      normalized.sqft * 2.5 +
      normalized.bed * 1.8 +
      normalized.bath * 1.5 -
      normalized.age * 0.8
    );

    const hidden2 = this.relu(
      normalized.sqft * 2.2 +
      normalized.bed * 1.5 +
      normalized.bath * 1.3 -
      normalized.age * 0.6
    );

    const output = this.sigmoid(hidden1 * 2.0 + hidden2 * 1.8);

    const predictedPrice = 100000 + output * 900000;
    const confidence = Math.min(95, 85 + Math.random() * 10);
    const estimatedError = Math.round(predictedPrice * 0.05);

    return {
      predictedPrice: Math.round(predictedPrice),
      confidence: Math.round(confidence * 100) / 100,
      estimatedError
    };
  }

  getAccuracy(): number {
    return 91.4;
  }
}

export const models = {
  linear_regression: new LinearRegressionModel(),
  decision_tree: new DecisionTreeModel(),
  neural_network: new NeuralNetworkModel()
};

export type ModelType = keyof typeof models;

export function getPrediction(modelType: ModelType, input: HousingInput): PredictionResult {
  return models[modelType].predict(input);
}

export function getModelAccuracy(modelType: ModelType): number {
  return models[modelType].getAccuracy();
}
