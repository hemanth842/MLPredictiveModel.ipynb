import { useState } from 'react';
import { Home } from 'lucide-react';
import { HousingInput } from '../services/mlModels';

interface InputFormProps {
  onPredict: (input: HousingInput) => void;
  isLoading: boolean;
}

export function InputForm({ onPredict, isLoading }: InputFormProps) {
  const [input, setInput] = useState<HousingInput>({
    squareFeet: 1800,
    bedrooms: 3,
    bathrooms: 2,
    ageYears: 15
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onPredict(input);
  };

  const handleChange = (field: keyof HousingInput, value: string) => {
    const numValue = parseFloat(value) || 0;
    setInput(prev => ({ ...prev, [field]: numValue }));
  };

  const fields = [
    { key: 'squareFeet' as const, label: 'Square Feet', min: 800, max: 5000, step: 50 },
    { key: 'bedrooms' as const, label: 'Bedrooms', min: 1, max: 6, step: 1 },
    { key: 'bathrooms' as const, label: 'Bathrooms', min: 1, max: 5, step: 0.5 },
    { key: 'ageYears' as const, label: 'Age (Years)', min: 0, max: 50, step: 1 }
  ];

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
        <Home className="w-5 h-5 text-blue-600" />
        Property Details
      </h2>

      <div className="space-y-6 mb-6">
        {fields.map((field) => (
          <div key={field.key}>
            <div className="flex justify-between items-center mb-2">
              <label className="text-sm font-semibold text-gray-700">
                {field.label}
              </label>
              <span className="text-lg font-bold text-blue-600">
                {input[field.key]}
                {field.key === 'squareFeet' && ' sq ft'}
                {field.key === 'bathrooms' && ''}
              </span>
            </div>
            <input
              type="range"
              min={field.min}
              max={field.max}
              step={field.step}
              value={input[field.key]}
              onChange={(e) => handleChange(field.key, e.target.value)}
              className="w-full accent-blue-600"
            />
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>{field.min}</span>
              <span>{field.max}</span>
            </div>
          </div>
        ))}
      </div>

      <button
        type="submit"
        disabled={isLoading}
        className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold py-4 px-6 rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLoading ? 'Analyzing...' : 'Predict Price'}
      </button>
    </form>
  );
}
