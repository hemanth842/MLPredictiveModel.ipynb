import { Clock, Home } from 'lucide-react';
import { Prediction } from '../lib/supabase';

interface PredictionHistoryProps {
  predictions: Prediction[];
}

const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(price);
};

export function PredictionHistory({ predictions }: PredictionHistoryProps) {
  if (predictions.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
          <Clock className="w-5 h-5 text-gray-600" />
          Prediction History
        </h2>
        <p className="text-center text-gray-500 py-8">No predictions yet</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
        <Clock className="w-5 h-5 text-gray-600" />
        Prediction History
      </h2>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {predictions.map((prediction) => (
          <div
            key={prediction.id}
            className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Home className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-semibold text-gray-700 capitalize">
                  {prediction.model_type.replace('_', ' ')}
                </span>
              </div>
              <span className="text-xs text-gray-500">
                {new Date(prediction.created_at).toLocaleString()}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="bg-white rounded p-2">
                <span className="text-gray-600 text-xs">Price:</span>
                <p className="font-bold text-blue-600">
                  {formatPrice(prediction.prediction_result.predictedPrice)}
                </p>
              </div>
              <div className="bg-white rounded p-2">
                <span className="text-gray-600 text-xs">Property:</span>
                <p className="font-bold text-gray-900">
                  {prediction.input_data.squareFeet} sq ft, {prediction.input_data.bedrooms}bd
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs mt-2">
              <div>
                <span className="text-gray-600">Confidence:</span>
                <span className="ml-1 font-bold text-green-700">
                  {prediction.prediction_result.confidence}%
                </span>
              </div>
              <div>
                <span className="text-gray-600">Model Accuracy:</span>
                <span className="ml-1 font-bold text-orange-700">
                  {prediction.accuracy}%
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
