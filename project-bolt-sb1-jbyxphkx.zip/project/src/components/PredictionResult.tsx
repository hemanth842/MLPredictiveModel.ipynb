import { CheckCircle, DollarSign, Target, Zap } from 'lucide-react';
import { PredictionResult as PredictionResultType } from '../services/mlModels';

interface PredictionResultProps {
  result: PredictionResultType | null;
  modelAccuracy: number;
}

const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(price);
};

export function PredictionResult({ result, modelAccuracy }: PredictionResultProps) {
  if (!result) {
    return (
      <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl shadow-lg p-12 text-center">
        <div className="inline-flex p-6 bg-white rounded-full shadow-md mb-4">
          <Target className="w-12 h-12 text-gray-400" />
        </div>
        <h3 className="text-xl font-bold text-gray-600 mb-2">No Prediction Yet</h3>
        <p className="text-gray-500">Enter property details and predict the price</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center gap-2 mb-6">
        <CheckCircle className="w-6 h-6 text-green-600" />
        <h2 className="text-xl font-bold text-gray-900">Predicted Price</h2>
      </div>

      <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-8 mb-6 text-center">
        <div className="flex justify-center items-center gap-2 mb-2">
          <DollarSign className="w-6 h-6 text-blue-600" />
          <span className="text-sm font-medium text-blue-700">Estimated Market Value</span>
        </div>
        <p className="text-4xl font-bold text-blue-900">
          {formatPrice(result.predictedPrice)}
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-5 h-5 text-green-600" />
            <span className="text-sm font-medium text-green-700">Confidence</span>
          </div>
          <p className="text-2xl font-bold text-green-900">{result.confidence}%</p>
        </div>

        <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Target className="w-5 h-5 text-orange-600" />
            <span className="text-sm font-medium text-orange-700">Model Accuracy</span>
          </div>
          <p className="text-2xl font-bold text-orange-900">{modelAccuracy}%</p>
        </div>
      </div>

      {result.estimatedError !== undefined && (
        <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg p-4">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-gray-700">Estimated Error Range</span>
            <span className="text-sm font-bold text-gray-900">
              ±{formatPrice(result.estimatedError)}
            </span>
          </div>
          <p className="text-xs text-gray-600 mt-1">
            Likely range: {formatPrice(result.predictedPrice - result.estimatedError)} - {formatPrice(result.predictedPrice + result.estimatedError)}
          </p>
        </div>
      )}
    </div>
  );
}
