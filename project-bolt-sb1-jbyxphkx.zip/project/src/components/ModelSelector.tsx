import { Brain, GitBranch, Network } from 'lucide-react';
import { ModelType } from '../services/mlModels';

interface ModelSelectorProps {
  selectedModel: ModelType;
  onSelectModel: (model: ModelType) => void;
}

const modelInfo = {
  linear_regression: {
    name: 'Linear Regression',
    icon: GitBranch,
    description: 'Simple and interpretable model for continuous predictions',
    accuracy: 87.5,
    color: 'from-blue-500 to-cyan-500'
  },
  decision_tree: {
    name: 'Decision Tree',
    icon: Brain,
    description: 'Rule-based model for classification and regression',
    accuracy: 91.2,
    color: 'from-green-500 to-emerald-500'
  },
  neural_network: {
    name: 'Neural Network',
    icon: Network,
    description: 'Deep learning model with multiple layers',
    accuracy: 93.8,
    color: 'from-orange-500 to-red-500'
  }
};

export function ModelSelector({ selectedModel, onSelectModel }: ModelSelectorProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {(Object.keys(modelInfo) as ModelType[]).map((modelKey) => {
        const model = modelInfo[modelKey];
        const Icon = model.icon;
        const isSelected = selectedModel === modelKey;

        return (
          <button
            key={modelKey}
            onClick={() => onSelectModel(modelKey)}
            className={`relative overflow-hidden rounded-xl p-6 text-left transition-all ${
              isSelected
                ? 'bg-white shadow-2xl scale-105 ring-4 ring-blue-500 ring-opacity-50'
                : 'bg-white shadow-lg hover:shadow-xl hover:scale-102'
            }`}
          >
            <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${model.color} opacity-10 rounded-bl-full`} />

            <div className="relative">
              <div className={`inline-flex p-3 rounded-lg bg-gradient-to-br ${model.color} mb-4`}>
                <Icon className="w-6 h-6 text-white" />
              </div>

              <h3 className="text-lg font-bold text-gray-900 mb-2">{model.name}</h3>
              <p className="text-sm text-gray-600 mb-4">{model.description}</p>

              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-gray-500">Accuracy</span>
                <span className="text-lg font-bold text-gray-900">{model.accuracy}%</span>
              </div>
            </div>
          </button>
        );
      })}
    </div>
  );
}
