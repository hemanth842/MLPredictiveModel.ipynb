import { useState, useEffect } from 'react';
import { Home } from 'lucide-react';
import { ModelSelector } from './components/ModelSelector';
import { InputForm } from './components/InputForm';
import { PredictionResult } from './components/PredictionResult';
import { PredictionHistory } from './components/PredictionHistory';
import { supabase, Prediction } from './lib/supabase';
import {
  ModelType,
  HousingInput,
  PredictionResult as PredictionResultType,
  getPrediction,
  getModelAccuracy
} from './services/mlModels';

function App() {
  const [selectedModel, setSelectedModel] = useState<ModelType>('linear_regression');
  const [result, setResult] = useState<PredictionResultType | null>(null);
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    loadPredictions();
  }, []);

  const loadPredictions = async () => {
    const { data, error } = await supabase
      .from('housing_predictions')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(10);

    if (!error && data) {
      const formattedData = data.map(item => ({
        id: item.id,
        model_type: item.model_type,
        input_data: {
          squareFeet: item.square_feet,
          bedrooms: item.bedrooms,
          bathrooms: item.bathrooms,
          ageYears: item.age_years
        },
        prediction_result: {
          predictedPrice: item.predicted_price,
          confidence: 88,
          estimatedError: Math.round(item.predicted_price * 0.07)
        },
        accuracy: 0,
        created_at: item.created_at
      }));
      setPredictions(formattedData as Prediction[]);
    }
  };

  const handlePredict = async (input: HousingInput) => {
    setIsLoading(true);

    setTimeout(async () => {
      const predictionResult = getPrediction(selectedModel, input);
      const accuracy = getModelAccuracy(selectedModel);

      setResult(predictionResult);

      const { error } = await supabase.from('housing_predictions').insert({
        model_type: selectedModel,
        square_feet: input.squareFeet,
        bedrooms: input.bedrooms,
        bathrooms: input.bathrooms,
        age_years: input.ageYears,
        predicted_price: predictionResult.predictedPrice
      });

      if (!error) {
        loadPredictions();
      }

      setIsLoading(false);
    }, 800);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <header className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-4 bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl shadow-xl mb-4">
            <Home className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-3">
            Housing Price Predictor
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            AI-powered prediction models to estimate real estate values
          </p>
        </header>

        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Select Prediction Model</h2>
          <ModelSelector
            selectedModel={selectedModel}
            onSelectModel={setSelectedModel}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <InputForm onPredict={handlePredict} isLoading={isLoading} />
          <PredictionResult
            result={result}
            modelAccuracy={getModelAccuracy(selectedModel)}
          />
        </div>

        <PredictionHistory predictions={predictions} />
      </div>
    </div>
  );
}

export default App;
